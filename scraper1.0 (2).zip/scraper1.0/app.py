from flask import Flask, render_template, request, jsonify
from bs4 import BeautifulSoup
import aiohttp
import asyncio
from multiprocessing import Process, Manager, cpu_count
from urllib.parse import urljoin
import firebase_admin
from firebase_admin import credentials, firestore

app = Flask(__name__)

# URL strony z której będziemy scrapować zdjęcia
BASE_URL = 'https://aniagotuje.pl/'

# Initialize Firebase Admin SDK
cred = credentials.Certificate('scraper-2e0d4-firebase-adminsdk-bo82d-52cef8f44d.json')
firebase_admin.initialize_app(cred)
db = firestore.client()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/firebase_data')
def firebase_data():
    # Pobierz dane z Firestore
    scraped_data_ref = db.collection('scraped_data')
    docs = scraped_data_ref.stream()

    data = []
    for doc in docs:
        data.append(doc.to_dict())

    return render_template('firebase_data.html', data=data)

async def fetch(session, url):
    async with session.get(url) as response:
        return await response.text()

async def scrape_images(shared_dict):
    async with aiohttp.ClientSession() as session:
        response_text = await fetch(session, BASE_URL)
        soup = BeautifulSoup(response_text, 'html.parser')
        img_tags = soup.find_all('img', {'loading': 'lazy', 'decoding': 'async'})
        image_urls = []
        article_urls = []
        for img_tag in img_tags:
            img_url = img_tag.get('src')
            image_urls.append(img_url)
            article_url = img_tag.find_parent('a').get('href')
            article_urls.append(article_url)
        shared_dict['image_urls'] = image_urls
        shared_dict['article_urls'] = article_urls

async def scrape_urls(shared_dict):
    async with aiohttp.ClientSession() as session:
        response_text = await fetch(session, BASE_URL)
        soup = BeautifulSoup(response_text, 'html.parser')
        article_links = soup.find_all('a', href=True)
        article_urls = [urljoin(BASE_URL, link['href']) for link in article_links if link['href'].startswith('/przepis/')]
        shared_dict['urls'] = article_urls

async def scrape_text_from_urls(urls, shared_dict, key):
    texts = []
    async with aiohttp.ClientSession() as session:
        tasks = [fetch(session, url) for url in urls]
        responses = await asyncio.gather(*tasks)
        for response_text in responses:
            soup = BeautifulSoup(response_text, 'html.parser')
            steps = soup.find_all('div', class_='step-text')
            recipe_text = '\n'.join([step.get_text(strip=True) for step in steps])
            texts.append(recipe_text)
    shared_dict[key] = texts

def run_scrape_images(shared_dict):
    asyncio.run(scrape_images(shared_dict))

def run_scrape_urls(shared_dict):
    asyncio.run(scrape_urls(shared_dict))

def run_scrape_text_from_urls(urls, shared_dict, key):
    asyncio.run(scrape_text_from_urls(urls, shared_dict, key))

@app.route('/scrap', methods=['POST'])
def scrap():
    manager = Manager()
    shared_dict = manager.dict()

    process_images = Process(target=run_scrape_images, args=(shared_dict,))
    process_urls = Process(target=run_scrape_urls, args=(shared_dict,))

    process_images.start()
    process_urls.start()

    process_images.join()
    process_urls.join()

    urls = shared_dict.get('urls', [])
    num_processes = min(cpu_count(), len(urls))
    chunk_size = len(urls) // num_processes

    processes = []
    for i in range(num_processes):
        chunk_urls = urls[i*chunk_size:(i+1)*chunk_size]
        process = Process(target=run_scrape_text_from_urls, args=(chunk_urls, shared_dict, f'texts_{i}'))
        processes.append(process)
        process.start()

    for process in processes:
        process.join()

    # Combine all texts
    texts = []
    for i in range(num_processes):
        texts.extend(shared_dict.get(f'texts_{i}', []))
    shared_dict['texts'] = texts

    # Save scraped data to Firestore
    db.collection('scraped_data').add(dict(shared_dict))

    return jsonify({"status": "success", "data": dict(shared_dict)})

@app.route('/data')
def data():
    shared_data = request.args.get('shared_data')
    shared_dict = eval(shared_data)

    image_urls = shared_dict.get('image_urls', [])
    article_urls = shared_dict.get('article_urls', [])
    recipe_texts = shared_dict.get('texts', [])

    return render_template('data.html', image_urls=image_urls, article_urls=article_urls, recipe_texts=recipe_texts)

if __name__ == '__main__':
    app.run(debug=True)
